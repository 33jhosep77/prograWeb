import React from "react";
import Whiteboard from "../src";

export default function Home() {
  return (
    <main>
      <Whiteboard />
    </main>
  );
}

export async function getStaticProps() {
  const API_KEY = process.env.LIVEBLOCKS_SECRET_KEY;
  const API_KEY_WARNING = process.env.CODESANDBOX_SSE
    ? `Add your secret key from https://liveblocks.io/dashboard/apikeys as the \`pk_dev_7F8oZr_q--F8Gkcq98ehncCEoGWIfqbQ9Kv1ExBPXHQ_bsb_nWTwZeyd95rcDC-v\` secret in CodeSandbox.\n` +
      `Learn more: https://github.com/liveblocks/liveblocks/tree/main/examples/nextjs-whiteboard#codesandbox.`
    : `Create an \`.env.local\` file and add your secret key from https://liveblocks.io/dashboard/apikeys as the \`pk_dev_7F8oZr_q--F8Gkcq98ehncCEoGWIfqbQ9Kv1ExBPXHQ_bsb_nWTwZeyd95rcDC-v\` environment variable.\n` +
      `Learn more: https://github.com/liveblocks/liveblocks/tree/main/examples/nextjs-whiteboard#getting-started.`;

  if (!API_KEY) {
    console.warn(API_KEY_WARNING);
  }

  return { props: {} };
}
