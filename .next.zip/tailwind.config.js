module.exports = {
  content: ["./components/**/*.tsx", "./pages/**/*.tsx"],
};
