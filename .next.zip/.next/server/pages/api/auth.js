"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/auth";
exports.ids = ["pages/api/auth"];
exports.modules = {

/***/ "@liveblocks/node":
/*!***********************************!*\
  !*** external "@liveblocks/node" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("@liveblocks/node");

/***/ }),

/***/ "(api)/./pages/api/auth.ts":
/*!***************************!*\
  !*** ./pages/api/auth.ts ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ auth)\n/* harmony export */ });\n/* harmony import */ var _liveblocks_node__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @liveblocks/node */ \"@liveblocks/node\");\n/* harmony import */ var _liveblocks_node__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_liveblocks_node__WEBPACK_IMPORTED_MODULE_0__);\n\nconst API_KEY = process.env.LIVEBLOCKS_SECRET_KEY;\nasync function auth(req, res) {\n    if (!API_KEY) {\n        return res.status(403).end();\n    }\n    const room = req.body.room;\n    const response = await (0,_liveblocks_node__WEBPACK_IMPORTED_MODULE_0__.authorize)({\n        room,\n        secret: API_KEY\n    });\n    return res.status(response.status).end(response.body);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvYXV0aC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBNkM7QUFHN0MsTUFBTUMsT0FBTyxHQUFHQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0MscUJBQXFCO0FBRWxDLGVBQWVDLElBQUksQ0FBQ0MsR0FBbUIsRUFBRUMsR0FBb0IsRUFBRTtJQUM1RSxJQUFJLENBQUNOLE9BQU8sRUFBRTtRQUNaLE9BQU9NLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxHQUFHLEVBQUUsQ0FBQztLQUM5QjtJQUVELE1BQU1DLElBQUksR0FBR0osR0FBRyxDQUFDSyxJQUFJLENBQUNELElBQUk7SUFFMUIsTUFBTUUsUUFBUSxHQUFHLE1BQU1aLDJEQUFTLENBQUM7UUFDL0JVLElBQUk7UUFDSkcsTUFBTSxFQUFFWixPQUFPO0tBQ2hCLENBQUM7SUFFRixPQUFPTSxHQUFHLENBQUNDLE1BQU0sQ0FBQ0ksUUFBUSxDQUFDSixNQUFNLENBQUMsQ0FBQ0MsR0FBRyxDQUFDRyxRQUFRLENBQUNELElBQUksQ0FBQyxDQUFDO0NBQ3ZEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQGxpdmVibG9ja3MvbmV4dGpzLXdoaXRlYm9hcmQtYWR2YW5jZWQvLi9wYWdlcy9hcGkvYXV0aC50cz9mYmVjIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGF1dGhvcml6ZSB9IGZyb20gXCJAbGl2ZWJsb2Nrcy9ub2RlXCI7XHJcbmltcG9ydCB7IE5leHRBcGlSZXF1ZXN0LCBOZXh0QXBpUmVzcG9uc2UgfSBmcm9tIFwibmV4dFwiO1xyXG5cclxuY29uc3QgQVBJX0tFWSA9IHByb2Nlc3MuZW52LkxJVkVCTE9DS1NfU0VDUkVUX0tFWTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGF1dGgocmVxOiBOZXh0QXBpUmVxdWVzdCwgcmVzOiBOZXh0QXBpUmVzcG9uc2UpIHtcclxuICBpZiAoIUFQSV9LRVkpIHtcclxuICAgIHJldHVybiByZXMuc3RhdHVzKDQwMykuZW5kKCk7XHJcbiAgfVxyXG5cclxuICBjb25zdCByb29tID0gcmVxLmJvZHkucm9vbTtcclxuXHJcbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhdXRob3JpemUoe1xyXG4gICAgcm9vbSxcclxuICAgIHNlY3JldDogQVBJX0tFWSxcclxuICB9KTtcclxuXHJcbiAgcmV0dXJuIHJlcy5zdGF0dXMocmVzcG9uc2Uuc3RhdHVzKS5lbmQocmVzcG9uc2UuYm9keSk7XHJcbn1cclxuIl0sIm5hbWVzIjpbImF1dGhvcml6ZSIsIkFQSV9LRVkiLCJwcm9jZXNzIiwiZW52IiwiTElWRUJMT0NLU19TRUNSRVRfS0VZIiwiYXV0aCIsInJlcSIsInJlcyIsInN0YXR1cyIsImVuZCIsInJvb20iLCJib2R5IiwicmVzcG9uc2UiLCJzZWNyZXQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/auth.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/auth.ts"));
module.exports = __webpack_exports__;

})();